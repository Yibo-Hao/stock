#import <Flutter/Flutter.h>

@interface FlutterAliAuthPlugin : NSObject<FlutterPlugin>
@end
